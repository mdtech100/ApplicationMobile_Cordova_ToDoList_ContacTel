function ajouterTache() {
    const task = document.getElementById('task');

    if (task.value) {
        const taskList = document.getElementById('taskList');
        taskList.innerHTML += `<li>${task.value}</li>`;
        $(taskList).listview('refresh');
        task.select();
    }
}

function reinitialiser() {
    const task = document.getElementById('task');
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';
    task.value = '';
    task.focus();
}