function ajouterTache() {
    const task = document.getElementById('task');

    if (task.value) {
        const taskList = document.getElementById('taskList');
        const newItem = document.createElement('li');
        newItem.innerHTML = task.value;
        // taskList.innerHTML += `<li>${task.value}</li>`;

        $(newItem).on('swiperight', function(){
            const completedTaskList = document.getElementById('completedTaskList');

            // Déplacer l'élément vers la liste des tâches terminées
            $(this).toggleClass('terminer');
            $(this).hide('slow', function() {
                completedTaskList.appendChild(this);
                $(completedTaskList).listview('refresh');
                $(this).show('slow');
            });
        });

        $(newItem).on('swipeleft', function(){
            const currentTaskList = document.getElementById('taskList');
            // Déplacer l'élément vers la liste des tâches en cours
            $(this).toggleClass('terminer');
            $(this).hide('slow', function() {
                currentTaskList.appendChild(this);
                $(currentTaskList).listview('refresh');
                $(this).show('slow');
                // $(this).remove();
            });
            // $(this).parentNode.removeChild('this');
        });

        // Ajouter l'élément à la liste des tâches en cours
        taskList.append(newItem);
        $(taskList).listview('refresh');
        task.select();
    }
}

function reinitialiser() {
    const task = document.getElementById('task');
    const taskList = document.getElementById('taskList');
    const completedTaskList = document.getElementById('completedTaskList');

    taskList.innerHTML = '';
    completedTaskList.innerHTML = '';
    task.value = '';
    task.focus();
}